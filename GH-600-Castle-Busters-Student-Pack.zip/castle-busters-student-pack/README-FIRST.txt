Castle Busters - GH-600 student starter pack (GitHub.com + VS Code)
===================================================================

Follow GH-600-Castle-Busters-Student-Guide.md. Each folder below matches one step in the guide.

How to add a step's files:
  1. Open the step folder (for example step-0.3-game).
  2. Copy everything INSIDE it (Ctrl+A then Ctrl+C on Windows, Cmd+A then Cmd+C on macOS).
  3. Paste into the root of your cloned castle-busters folder. If asked, choose to merge folders.
  4. Check the VS Code Explorer: the files should appear under the same paths, for example .github/agents/.

Folders that start with a dot (.github, .vscode) are hidden by default.
  Windows: File Explorer > View > Show > Hidden items.
  macOS:   press Cmd+Shift+. (full stop) in Finder.

step-0.3-game            Lab 0     game code, tests, README, .gitignore
step-2.1-house-rules     Part 2    Copilot instructions for the whole repo and for tests
step-2.2-sdlc            Part 2    agent-task issue form, PR template, CODEOWNERS, plan check, planner agent, memory files
step-3.1-agents-and-ci   Part 3    game-dev and test-guardian agents, Copilot setup steps, CI
step-3.3-mcp             Part 3    VS Code MCP servers file, repository MCP config to copy into Settings
step-3.6-agent-dispatch  Part 3    optional: workflow that starts an agent from CI with retries
step-4.5-registry        Part 4    agent registry
step-5.4-prompt-file     Part 5    reusable /new-level prompt file
step-6.1-autonomy        Part 6    autonomy levels table
step-6.2-hooks           Part 6    guardrail hook and its script
step-6.4-release         Part 6    release workflow with human approval
complete-solution        all       the finished repository, for reference only
