"""Play Castle Busters in a window (uses turtle, which ships with Python).

Run:  python -m castle_busters.game
"""

import turtle

from .castle import level_one
from .physics import Shot, trajectory
from .scoring import final_score, score_hit

SCALE = 2  # pixels per metre
GROUND_Y = -200
LEFT_X = -380
MAX_SHOTS = 5


def draw_castle(pen: turtle.Turtle, castle) -> None:
    colours = {"wood": "sienna", "stone": "gray", "tower": "firebrick"}
    for block in castle.blocks:
        if not block.standing:
            continue
        pen.penup()
        pen.goto(LEFT_X + block.x * SCALE, GROUND_Y)
        pen.setheading(0)
        pen.color(colours[block.kind])
        pen.begin_fill()
        for side in (block.width * SCALE, 40, block.width * SCALE, 40):
            pen.forward(side)
            pen.left(90)
        pen.end_fill()


def play() -> None:
    screen = turtle.Screen()
    screen.title("Castle Busters")
    screen.setup(820, 480)
    pen = turtle.Turtle(visible=False)
    pen.speed(0)
    castle = level_one()
    points, shots = 0, 0

    while shots < MAX_SHOTS and not castle.destroyed:
        pen.clear()
        draw_castle(pen, castle)
        angle = screen.numinput("Aim", "Angle (1-89 degrees):", 45, 1, 89)
        power = screen.numinput("Power", "Power (1-100):", 40, 1, 100)
        if angle is None or power is None:
            break
        shots += 1
        path = trajectory(Shot(angle, power))
        pen.penup()
        pen.color("black")
        for x, y in path:
            pen.goto(LEFT_X + x * SCALE, GROUND_Y + y * SCALE)
            pen.pendown()
        points += score_hit(castle.hit(path[-1][0]))

    result = "CASTLE BUSTED!" if castle.destroyed else "Out of boulders"
    total = final_score(points, max(shots, 1))
    pen.penup()
    pen.goto(0, 150)
    pen.write(f"{result}  Score: {total}", align="center", font=("Arial", 20, "bold"))
    screen.mainloop()


if __name__ == "__main__":
    play()
