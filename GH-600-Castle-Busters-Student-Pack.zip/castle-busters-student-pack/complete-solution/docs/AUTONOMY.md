# Castle Busters - agent autonomy levels

| Action | Risk | Autonomy | Control that enforces it |
|---|---|---|---|
| Write or fix tests, docs, plans | Low | Agent may finish; normal PR | Required status checks |
| Change game rules (castle_busters/) | Medium | PR + code owner review | Ruleset + CODEOWNERS |
| Change scoring.py | Medium-High | PR + code owner review | CODEOWNERS path rule |
| Change .github/workflows/ | High | Human only | Hook blocks agent edits; CODEOWNERS |
| Release a new version | High | Human approval before run | production environment reviewer |
| Force push / delete branches | Blocked | Never | Ruleset + hook |
