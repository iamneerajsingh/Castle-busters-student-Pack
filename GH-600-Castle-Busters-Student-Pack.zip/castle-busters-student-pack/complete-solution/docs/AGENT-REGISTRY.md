# Agent registry (lifecycle)

| Agent | File | Status | Version | Added | Notes |
|---|---|---|---|---|---|
| planner | .github/agents/planner.agent.md | Active | 1 | 2026-11-24 | Writes plans only |
| game-dev | .github/agents/game-dev.agent.md | Active | 1 | 2026-11-24 | Implements approved plans |
| test-guardian | .github/agents/test-guardian.agent.md | Active | 1 | 2026-11-24 | Tests only |

To retire an agent: open a PR that deletes its file and marks it "Retired" here.
Git history keeps the old file, so audits still work.
