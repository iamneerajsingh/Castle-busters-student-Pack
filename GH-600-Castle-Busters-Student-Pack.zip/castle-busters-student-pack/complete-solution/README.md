# Castle Busters

A tiny catapult-and-castle game in Python, used to demonstrate the GH-600 (Developing in Agentic AI Systems) skills.

## Play
```
python -m castle_busters.game
```
Pick an angle and a power. Knock down all three blocks with as few boulders as possible.
(Hint: angle 45 and power about 38.5 hits the wooden block.)

## Test
```
pip install -r requirements-dev.txt
python -m pytest -q
ruff check .
```
