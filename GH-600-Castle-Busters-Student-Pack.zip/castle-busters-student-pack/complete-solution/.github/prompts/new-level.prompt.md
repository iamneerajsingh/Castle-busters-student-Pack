---
description: Design a new Castle Busters level with tests
agent: agent
---
Create a new level function `level_${input:number}()` in `castle_busters/castle.py`.

Requirements:
- ${input:blocks} blocks, mixing wood, stone and tower.
- At least one block must be reachable with angle 45 and power between 30 and 60.
- Add a test in `tests/test_levels.py` that proves the reachable block can be hit.
- Follow the rules in `.github/copilot-instructions.md`.
