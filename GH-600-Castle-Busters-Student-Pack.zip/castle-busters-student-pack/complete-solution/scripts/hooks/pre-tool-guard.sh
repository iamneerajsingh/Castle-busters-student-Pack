#!/bin/bash
# Guardrail hook: runs BEFORE the agent uses any tool.
# 1) Writes every tool request to logs/agent-audit.log (traceability)
# 2) Blocks dangerous shell commands
# 3) Blocks changes to workflow files (reading them is still allowed)
INPUT=$(cat)
mkdir -p logs
echo "$(date -u +%FT%TZ) $INPUT" >> logs/agent-audit.log

deny() {
  echo "{\"permissionDecision\":\"deny\",\"permissionDecisionReason\":\"$1\"}"
  exit 0
}

case "$INPUT" in
  *"rm -rf"*)           deny "Castle Busters guardrail: rm -rf is not allowed" ;;
  *"git push --force"*) deny "Castle Busters guardrail: force push is not allowed" ;;
esac

# Any tool other than view/read that mentions a workflow file is blocked
if echo "$INPUT" | grep -q '.github/workflows/' && ! echo "$INPUT" | grep -qE '"toolName" *: *"(view|read)"'; then
  deny "Castle Busters guardrail: workflow files need a human change"
fi
exit 0
